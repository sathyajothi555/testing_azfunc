import logging
import azure.functions as func
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import json 
from datetime import datetime, timedelta

app = func.FunctionApp()

@app.event_grid_trigger(arg_name="azeventgrid")
def EventGridTriggersrini(azeventgrid: func.EventGridEvent):
    result = json.dumps({
        'id': azeventgrid.id,
        'data': azeventgrid.get_json(),
        'topic': azeventgrid.topic,
        'subject': azeventgrid.subject,
        'event_type': azeventgrid.event_type,
    })
    result_dict = json.loads(result)
    mail_data = f''' 
    Hi,  {result_dict['data']['claims']['name']}

    A resource has been created. The details are given below.

    Activity ID             = {result_dict['id']}
    Resource Provider       = {result_dict['data']['resourceProvider']}
    Operation Name          = {result_dict['data']['operationName']}
    Status                  = {result_dict['data']['status']}
    Subscription ID         = {result_dict['data']['subscriptionId']}
    Tenant ID               = {result_dict['data']['tenantId']}
    Topic                   = {result_dict['topic']}
    Subject                 = {result_dict['subject']}
    Event Type              = {result_dict['event_type']}
    Resource URI            = {result_dict['data']['resourceUri']}
    Time                    = {str(azeventgrid.event_time)}
    '''


    smtp_server = "smtp.gmail.com"
    smtp_port = 587
    sender_email = "srinivas@tivonaglobal.com"
    sender_password = "bbffbvfshmcehiyl"
    email = "hdex2k1@gmail.com"

    message = MIMEMultipart() 
    message['Subject'] = "creation of resources"
    message['From'] = sender_email
    message['To'] = email
    message.attach(MIMEText(f'RESOURCE CREATION ALERT {mail_data} '))

    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email,email, message.as_string())
        print("mail sent")
    
    logging.info('Python EventGrid trigger processed an event')
